# Literkowa przygoda

Polish early-reading app. Buildless: serve `dist/`.

## Content review
- 32 Polish alphabet letters in order, including Ą Ć Ę Ł Ń Ó Ś Ź Ż. Q V X excluded.
- Examples for Ą, Ę, Ń, Y are explicitly inside words, not asserted to be word initials.
- 18 reviewed practice words. Syllables: ma-ma, ta-ta, kot, dom, lis, so-wa, ry-ba, wo-da, lo-dy, bu-ty, ża-ba, ma-pa, ba-nan, mo-tyl, gi-ta-ra, rak, tort, fo-ka.
- Alphabet reference: https://zpe.gov.pl/a/zaszyfrowana-wiadomosc/D12CHdZf5
- Distinction between letters, phonemes and syllables: https://zpe.gov.pl/a/nie-trac-gruntu-pod-nogami-nie-myl-glosek-z-literami/D10I8pLqZ
- Dictionary spot checks: https://wsjp.pl/haslo/podglad/53177/cma/5154539/motyl and https://wsjp.pl/haslo/podglad/13697/lala/5139302/zabawka . The new syllable bank uses the words listed above.

## Audio
67 pre-generated Polish synthetic speech clips, pl-PL-ZofiaNeural, rate -8%. `audio-manifest.json` maps literal Polish text to MP3 assets. No browser speechSynthesis fallback. Whole-word recordings are not presented as isolated phonemes. Playback is user-triggered, interruptible and mutable. Rendering does not require audio or an external TTS service. Font falls back to device fonts if Google Fonts is unavailable.

## Validation
JavaScript syntax and data invariants checked. All 67 MP3 files checked for nonempty data and valid duration. Browser tested five-round word-building flow, repeated letters, reward unlock, wrong/right letter choice, syllable view, and a 390px iframe viewport. Actual iOS hardware and subjective voice quality not verified here.

Stars, explored letters and mute preference are saved in browser localStorage. No child accounts or analytics.

## Expanded edition
224 words across 7 categories; 75 CV syllables; 7 activity modes, including syllable assembly and picture-free independent reading. Search, syllable-count filters and 12-card pagination. Reading mode offers optional syllable hints and audio after independent reading; no automated assessment. Additional original SVG illustrations and reduced-motion-aware feedback animations.

## Learning product edition
12 progressive lessons; 5 XP per completed exercise, one-time lesson bonus 20 XP. Daily 30 XP target uses Europe/Warsaw calendar dates; completed-goal days accumulate without a streak penalty. Data is browser-local, with JSON export/import. No account sync, server profiles or speech assessment. PWA manifest and same-origin service worker cache the app shell and played audio; the parent panel downloads the full audio bank on request. Browser storage eviction and private hosting authentication can limit offline availability. Test installation/offline on target iOS and Android before a broader commercial launch. Accessibility includes keyboard focus, text labels and reduced motion.

## Colored-pencil illustration edition
All 226 educational/mascot art keys map to eight optimized WebP sprite atlases under dist/illustrations. Realistic colored-pencil artwork was generated using the built-in image generation tool with natural proportions, warm paper backgrounds and no emoji or vector styling. Prompt template: isolated naturalist encyclopedia drawings, detailed colored-pencil hatching, exact row-major Polish subject list, 5 columns by 6 rows, no captions. The last sheet was normalized from a 5-row canvas into the common 6-row atlas. Raster preparation preserves aspect ratio. Existing SVG source retained for source history; runtime uses pencil-art.js. Main fox, lesson illustrations, alphabet examples, stickers and PWA icon updated. Reading-only mode remains image-free.

## Systematic Polish reading revision
345 lexical items, 8 comprehension sentences. Course now starts with vowels, adds cumulative consonant sets and decodable targets, then introduces marked Polish spellings/digraphs and sentence meaning. A teacher/parent supplies isolated consonant modelling; synthetic whole-word or syllable audio is never described as an isolated consonant. Digraph tokens remain intact in assembly. Alternating word exercises distinguish auditory spelling/assembly from text-to-recording decoding. Incorrect trials queue one within-session retrieval repetition. This is an authored educational aid informed by IBE principles, not a certified intervention, diagnosis, automatic speech assessment or proof of mastery. Parent guidance explicitly separates task completion from independent reading. Old category-course completions are archived; XP is retained when restarting the revised curriculum.

Primary methodology references: https://przewodnik.ibe.edu.pl/metoda-foniczna ; https://zpe.gov.pl/a/podstawy-czytania-i-pisania/D1X752BVS ; https://przewodnik.ibe.edu.pl/strategie-czytania-ze-zrozumieniem . English-language intervention findings are not treated as a measured effect size for this Polish app.

Image bug fix: per-object WebP files replace CSS atlas backgrounds; explicit object-fit:contain and responsive dimensions eliminate adjacent-cell bleeding and unequal atlas stretching. 226 individual illustration files match the catalog. Added vocabulary is text-only rather than assigned unrelated illustrations. Illustrations are revealed after answers in the course.
